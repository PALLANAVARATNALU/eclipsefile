		public class student1 {
			//sample method
			public void name() {
				System.out.println("hello students");
			}
			public void age() {
				System.out.println("student age is 20");
			}
			public void phone() {
				System.out.println("98765432");
			}
				//main method
				public static void main(String args[]) {
					//creation of object
					student1 std=new student1();
					std.name();
					std.age();
					std.phone();
				}

			}


